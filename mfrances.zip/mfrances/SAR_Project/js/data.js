const mockEvents = [
    {
        id: 1,
        title: "Introduction to AI",
        date: "2024-10-15",
        type: "Seminar",
        location: "Main Hall",
        description: "A comprehensive overview of Artificial Intelligence trends in 2024.",
        materials: ["Slides.pdf", "Recording.mp4"]
    },
    {
        id: 2,
        title: "Web Dev Workshop",
        date: "2024-11-05",
        type: "Workshop",
        location: "Lab 3",
        description: "Hands-on session building a React application from scratch.",
        materials: ["Code_Repo.zip", "Cheatsheet.pdf"]
    },
    {
        id: 3,
        title: "Cyber Security Talk",
        date: "2024-11-20",
        type: "Seminar",
        location: "Room 101",
        description: "Guest speaker details the importance of Zero Trust architecture.",
        materials: ["Presentation.pptx"]
    },
    {
        id: 4,
        title: "Hackathon Closing",
        date: "2024-12-01",
        type: "Competition",
        location: "Auditorium",
        description: "Award ceremony for the annual university hackathon.",
        materials: ["Winners_List.pdf", "Photos.zip"]
    }
];
