const calendarGrid = document.getElementById('calendarGrid');
const monthYearLabel = document.getElementById('monthYear');
const prevBtn = document.getElementById('prevMonth');
const nextBtn = document.getElementById('nextMonth');

let currentDate = new Date();

function renderCalendar() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    monthYearLabel.textContent = new Date(year, month).toLocaleString('default', { month: 'long', year: 'numeric' });

    // First day of the month
    const firstDayIndex = new Date(year, month, 1).getDay();
    // Last day of the month
    const lastDay = new Date(year, month + 1, 0).getDate();
    // Last day of prev month
    const prevLastDay = new Date(year, month, 0).getDate();

    let days = "";

    // Prev month days
    for (let x = firstDayIndex; x > 0; x--) {
        days += `<div class="day prev-date">${prevLastDay - x + 1}</div>`;
    }

    // Current month days
    for (let i = 1; i <= lastDay; i++) {
        // Check for events
        // Note: In a real app we would match ISO strings or similar. 
        // Here we just check if our mockEvents have this day (very simple match).
        let eventDot = "";
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;

        // Simple check against mockEvents from data.js
        if (typeof mockEvents !== 'undefined') {
            const hasEvent = mockEvents.some(e => e.date === dateStr);
            if (hasEvent) {
                eventDot = `<div class="event-dot" title="Event on this day"></div>`;
            }
        }

        if (i === new Date().getDate() && year === new Date().getFullYear() && month === new Date().getMonth()) {
            days += `<div class="day today">${i}${eventDot}</div>`;
        } else {
            days += `<div class="day">${i}${eventDot}</div>`;
        }
    }

    calendarGrid.innerHTML = days;
}

prevBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar();
});

nextBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar();
});

// Initial Render
renderCalendar();
