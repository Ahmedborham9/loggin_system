// Loading Screen
window.addEventListener('load', () => {
    setTimeout(() => {
        document.getElementById('loading')?.remove();
    }, 1000);
});

// Theme Toggle
document.getElementById('themeToggle')?.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
});

// Check saved theme
if (localStorage.getItem('darkMode') === 'true') {
    document.body.classList.add('dark-mode');
}

// Login Form
document.getElementById('loginForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    
    if (email === user.email && password === user.password) {
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('currentUser', JSON.stringify(user));
        alert('تم تسجيل الدخول بنجاح! 🎉');
        window.location.href = 'dashboard.html';
    } else {
        alert('بيانات الدخول غير صحيحة!');
    }
});

// Register Form (في register.html)
document.getElementById('registerForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const studentId = document.getElementById('studentId').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (password !== confirmPassword) {
        alert("كلمات المرور غير متطابقة!");
        return;
    }

    const user = { name, studentId, email, password };
    localStorage.setItem('user', JSON.stringify(user));
    alert("تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول.");
    window.location.href = 'login.html';
});

// Check Login Status
function checkAuth() {
    if (localStorage.getItem('isLoggedIn') !== 'true') {
        window.location.href = 'login.html';
    }
}
